#include <stdio.h>

#define MILLION 1000000

void subroutine()
{
	for (int i=0;i<100*MILLION ;i++ )
		;
	return;
}

void loop_100_million()
{
	for (int i=0;i<100*MILLION ;i++ )
		;
	subroutine();
	return;
}

void loop_1000_million()
{
	for (int i=0;i<1000*MILLION ;i++ )
		;
	subroutine();
	return;
}

int main(int argc,char* *argv)
{
	loop_100_million();
	loop_100_million();
	loop_100_million();
	loop_1000_million();
	loop_1000_million();
	return 1;
}