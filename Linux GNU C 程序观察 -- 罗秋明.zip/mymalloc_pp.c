#ifdef INTERPOSIT_IN_PREP
#include <stdio.h>
#include <malloc.h>

void *mymalloc(size_t size)
{
	void *ptr=malloc(size);
	printf("malloc(%d) at addr %p\n",(int)size,ptr);
	return ptr;
}

void myfree(void *ptr)
{
	free(ptr);
	printf("free at(%p)\n",ptr);
}
#endif