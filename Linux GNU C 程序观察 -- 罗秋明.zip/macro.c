#include <stdio.h>
#define NUM 5
int main(void)
{
	printf("Value of Num is %d\n",NUM);
	
	return 0;
}
