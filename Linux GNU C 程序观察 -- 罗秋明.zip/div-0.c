#include <stdio.h>

int main()
{
	int var_sum=0;
	var_sum=var_sum/0;
	
	return 0;
}
