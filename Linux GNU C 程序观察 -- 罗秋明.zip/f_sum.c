int f_sum(int a, int b)
{
	return a+b;
}
