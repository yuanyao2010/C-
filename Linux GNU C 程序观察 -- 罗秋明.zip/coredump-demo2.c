#include <stdio.h>

int main()
{
	int a=0x1111;
	int b=0x800000;
	int *c;
	c=b;
	*c=*c+a;
	return *c;
}
