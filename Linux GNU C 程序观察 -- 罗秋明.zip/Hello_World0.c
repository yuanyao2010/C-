#include <stdio.h>

int f_sum(int a,int b);
int main()
{
	int var_sum=0;
	printf("HelloWorld!\n");
	var_sum=f_sum(2,3);
	return var_sum;
	
	
}
