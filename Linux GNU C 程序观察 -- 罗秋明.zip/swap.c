void swap (long *xp,long *yp)
{
	long t0 = *xp;
	long t1 = *yp;
	*xp = t1;
	*yp = t0;
}