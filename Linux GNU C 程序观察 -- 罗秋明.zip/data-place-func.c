int c;
int d=200;
int func(int x,int y)
{
	int k;
	c=x+d;
	k=c*y;
	return k;
}
