#include <stdio.h>

void core_test1()
{
	int i=0;
	scanf("%d",i);
	printf("%d\n",i);
}

int main()
{
	core_test1();
	return 0;
}